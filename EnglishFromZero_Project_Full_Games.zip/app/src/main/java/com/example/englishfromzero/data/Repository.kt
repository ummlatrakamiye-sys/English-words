
package com.example.englishfromzero.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class Repository private constructor(private val db: AppDatabase) {

    companion object {
        @Volatile private var instance: Repository? = null
        fun getInstance(context: Context): Repository =
            instance ?: synchronized(this) {
                instance ?: build(context).also { instance = it }
            }

        private fun build(context: Context): Repository {
            val db = Room.databaseBuilder(context, AppDatabase::class.java, "words.db")
                .createFromAsset("databases/words.db")
                .fallbackToDestructiveMigration()
                .build()
            return Repository(db)
        }
    }

    suspend fun loadDueWords(limit: Int = 200): List<WordItem> = withContext(Dispatchers.IO) {
        db.wordDao().loadDueWords(System.currentTimeMillis(), limit)
    }

    suspend fun countNewWords(): Int = withContext(Dispatchers.IO) {
        db.wordDao().countNewWords()
    }

    suspend fun updateWord(item: WordItem) = withContext(Dispatchers.IO) {
        db.wordDao().update(item)
    }
}
