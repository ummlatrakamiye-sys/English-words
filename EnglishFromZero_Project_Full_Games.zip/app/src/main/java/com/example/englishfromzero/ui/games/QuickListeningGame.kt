
package com.example.englishfromzero.ui.games

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.englishfromzero.data.WordItem

@Composable
fun QuickListeningGame(words: List<WordItem>, speak: (String)->Unit, onFinish: (Int)->Unit) {
    var score by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf(words.random()) }
    var options by remember { mutableStateOf(listOf<String>()) }
    var remaining by remember { mutableStateOf(10) }

    fun next() {
        if (remaining <= 0) {
            onFinish(score)
            return
        }
        current = words.random()
        val correct = current.english
        val wrong = words.shuffled().take(3).map { it.english }
        options = (wrong + correct).shuffled()
        speak(correct)
        remaining--
    }

    LaunchedEffect(Unit) {
        next()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("النقاط: $score")
        Text("المتبقي: $remaining")
        options.forEach { opt ->
            Button(onClick = {
                if (opt == current.english) score += 10
                next()
            }, modifier = Modifier.fillMaxWidth()) {
                Text(opt)
            }
        }
    }
}
