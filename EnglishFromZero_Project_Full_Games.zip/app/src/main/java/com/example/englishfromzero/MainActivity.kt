
package com.example.englishfromzero

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.englishfromzero.ui.DashboardScreen
import com.example.englishfromzero.ui.ReviewScreen
import com.example.englishfromzero.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val due by vm.due.collectAsState()
            val points by vm.points.collectAsState()
            // simple flow: show dashboard then review when button pressed
            DashboardScreen(onStartReview = { vm.loadDue() }, points = points, newCount = 0, dueCount = due.size)
            // Note: this is simplified. For full navigation use Navigation Compose.
        }
    }
}
