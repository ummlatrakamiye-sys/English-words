
package com.example.englishfromzero.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun GamesScreen(onStartTimed: ()->Unit, onStartAssemble: ()->Unit, onStartListen: ()->Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "الألعاب التعليمية")
        Button(onClick = onStartTimed, modifier = Modifier.fillMaxWidth()) { Text(text = "لعبة التحدي الزمني") }
        Button(onClick = onStartAssemble, modifier = Modifier.fillMaxWidth()) { Text(text = "لعبة تركيب الجمل") }
        Button(onClick = onStartListen, modifier = Modifier.fillMaxWidth()) { Text(text = "لعبة الاستماع السريع") }
    }
}
