package com.example.englishfromzero.data

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Insert
import androidx.room.Update

@Dao
interface WordDao {
    @Query("SELECT * FROM words WHERE nextReview <= :now ORDER BY nextReview ASC LIMIT :limit")
    suspend fun loadDueWords(now: Long, limit: Int): List<WordItem>

    @Query("SELECT COUNT(*) FROM words WHERE isNew = 1")
    suspend fun countNewWords(): Int

    @Insert
    suspend fun insertAll(items: List<WordItem>)

    @Update
    suspend fun update(item: WordItem)
}
