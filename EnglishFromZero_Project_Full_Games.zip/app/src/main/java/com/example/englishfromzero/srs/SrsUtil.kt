
package com.example.englishfromzero.srs

object SrsUtil {
    // Quality: 5 (perfect) ... 0 (complete blackout)
    fun updateAfterReview(repetition: Int, intervalDays: Int, easeFactor: Float, quality: Int): Triple<Int, Int, Float> {
        var rep = repetition
        var interval = intervalDays
        var ef = easeFactor
        if (quality < 3) {
            rep = 0
            interval = 1
            // reduce EF slightly
            ef = (ef - 0.2f).coerceAtLeast(1.3f)
        } else {
            rep += 1
            when (rep) {
                1 -> interval = 1
                2 -> interval = 6
                else -> interval = (interval * ef).toInt().coerceAtLeast(1)
            }
            // update EF per SM-2 formula (simplified)
            ef = (ef + (0.1f - (5 - quality) * (0.08f + (5 - quality) * 0.02f))).coerceAtLeast(1.3f)
        }
        return Triple(rep, interval, ef)
    }
}
