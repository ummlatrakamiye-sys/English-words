
package com.example.englishfromzero.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import com.example.englishfromzero.data.WordItem
import java.util.*

@Composable
fun ReviewScreen(words: List<WordItem>, onEvaluate: (WordItem, Int) -> Unit, speak: (String)->Unit) {
    var index by remember { mutableStateOf(0) }
    if (words.isEmpty()) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "لا توجد كلمات للمراجعة الآن")
        }
        return
    }
    val word = words.getOrNull(index) ?: words.first()
    var showEnglish by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = word.arabic, style = MaterialTheme.typography.h5)
                Spacer(modifier = Modifier.height(12.dp))
                if (showEnglish) Text(text = word.english)
                Spacer(modifier = Modifier.height(12.dp))
                Row {
                    IconButton(onClick = { speak(word.english) }) { Text(text = "🔊") }
                    Button(onClick = { showEnglish = !showEnglish }) { Text(text = if (showEnglish) "اخفاء" else "إظهار الترجمة") }
                }
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onEvaluate(word, 5); index = (index + 1) % words.size }, modifier = Modifier.weight(1f)) { Text(text = "سهل") }
            Button(onClick = { onEvaluate(word, 4); index = (index + 1) % words.size }, modifier = Modifier.weight(1f)) { Text(text = "متوسط") }
            Button(onClick = { onEvaluate(word, 2); index = (index + 1) % words.size }, modifier = Modifier.weight(1f)) { Text(text = "صعب") }
            Button(onClick = { onEvaluate(word, 0); index = (index + 1) % words.size }, modifier = Modifier.weight(1f)) { Text(text = "خطأ") }
        }
    }
}
