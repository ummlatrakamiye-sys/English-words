
package com.example.englishfromzero.viewmodel

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.englishfromzero.data.Repository
import com.example.englishfromzero.data.WordItem
import com.example.englishfromzero.srs.SrsUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = Repository.getInstance(application.applicationContext)
    private val _due = MutableStateFlow<List<WordItem>>(emptyList())
    val due: StateFlow<List<WordItem>> = _due

    // simple points and goals
    private val _points = MutableStateFlow(0)
    val points: StateFlow<Int> = _points

    var tts: TextToSpeech? = null

    init {
        viewModelScope.launch { loadDue() }
        tts = TextToSpeech(application.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, text.hashCode().toString())
    }

    fun setVoiceLocale(locale: Locale) {
        tts?.language = locale
    }

    fun loadDue() = viewModelScope.launch {
        val list = repo.loadDueWords(500)
        _due.value = list
    }

    fun reviewWord(word: WordItem, quality: Int) = viewModelScope.launch {
        val (rep, interval, ef) = SrsUtil.updateAfterReview(word.repetition, word.intervalDays, word.easeFactor, quality)
        val now = System.currentTimeMillis()
        val updated = word.copy().apply {
            repetition = rep
            intervalDays = interval
            easeFactor = ef
            lastSeen = now
            nextReview = now + interval * 24 * 60 * 60 * 1000L
            correctCount = if (quality >= 3) correctCount + 1 else correctCount
            incorrectCount = if (quality < 3) incorrectCount + 1 else incorrectCount
            isNew = 0
        }
        repo.updateWord(updated)
        // award points
        if (quality >= 3) _points.value += 10
        else _points.value += 1
        loadDue()
    }

    override fun onCleared() {
        super.onCleared()
        tts?.shutdown()
    }
}
