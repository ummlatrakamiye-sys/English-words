
package com.example.englishfromzero.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DashboardScreen(onStartReview: () -> Unit, points: Int, newCount: Int, dueCount: Int) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "الصفحة الرئيسية", modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "النقاط: $points")
                Text(text = "كلمات جديدة متاحة: $newCount")
                Text(text = "كلمات للمراجعة الآن: $dueCount")
            }
        }
        Button(onClick = onStartReview, modifier = Modifier.fillMaxWidth()) { Text(text = "ابدأ المراجعة") }
        Button(onClick = { /* navigate to games */ }, modifier = Modifier.fillMaxWidth()) { Text(text = "الألعاب التعليمية") }
    }
}
