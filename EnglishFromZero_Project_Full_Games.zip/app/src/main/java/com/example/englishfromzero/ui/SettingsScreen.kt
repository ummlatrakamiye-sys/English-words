
package com.example.englishfromzero.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.Switch
import androidx.compose.material.Text
import androidx.compose.material.Row
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(isDarkMode: Boolean, onToggleDark: (Boolean)->Unit, ttsRate: Float, onRateChange: (Float)->Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "الإعدادات")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "الوضع الليلي")
            Switch(checked = isDarkMode, onCheckedChange = onToggleDark)
        }
        // speed control (placeholder)
        Text(text = "سرعة النطق: ${ttsRate}")
    }
}
