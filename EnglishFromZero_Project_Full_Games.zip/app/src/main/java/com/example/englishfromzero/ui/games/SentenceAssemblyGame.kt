
package com.example.englishfromzero.ui.games

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.englishfromzero.data.WordItem
import kotlin.random.Random

@Composable
fun SentenceAssemblyGame(words: List<WordItem>, onFinish: () -> Unit) {
    var current by remember { mutableStateOf(words.random()) }
    var shuffled by remember { mutableStateOf(current.english.split(" ").shuffled()) }
    var assembled by remember { mutableStateOf(listOf<String>()) }
    var score by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الجملة بالعربية: ${current.arabic}")
        Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            Row(modifier = Modifier.padding(12.dp)) {
                assembled.forEach { part ->
                    Text("$part ", modifier = Modifier.padding(4.dp))
                }
            }
        }
        FlowRow(mainAxisSpacing = 8.dp, crossAxisSpacing = 8.dp) {
            shuffled.forEach { word ->
                Text(word, modifier = Modifier.clickable {
                    assembled = assembled + word
                    shuffled = shuffled - word
                }.padding(4.dp))
            }
        }
        Button(onClick = {
            if (assembled.joinToString(" ") == current.english) {
                score += 10
            }
            current = words.random()
            shuffled = current.english.split(" ").shuffled()
            assembled = listOf()
        }) { Text("تحقق وانتقل") }
        Text("النقاط: $score")
    }
}
