package com.example.englishfromzero.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "words")
data class WordItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val arabic: String,
    val english: String,
    val nextReview: Long = 0L,
    val intervalDays: Int = 0,
    val easeFactor: Float = 2.5f,
    val repetition: Int = 0,
    val correctCount: Int = 0,
    val incorrectCount: Int = 0,
    val lastSeen: Long = 0L,
    val createdAt: Long = 0L,
    val isNew: Int = 1
)
