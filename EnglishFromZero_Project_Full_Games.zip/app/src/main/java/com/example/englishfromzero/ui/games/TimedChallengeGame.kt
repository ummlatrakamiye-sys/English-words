
package com.example.englishfromzero.ui.games

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.englishfromzero.data.WordItem
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun TimedChallengeGame(words: List<WordItem>, onFinish: (Int) -> Unit) {
    var score by remember { mutableStateOf(0) }
    var timeLeft by remember { mutableStateOf(60) } // seconds
    var currentWord by remember { mutableStateOf<WordItem?>(null) }
    var options by remember { mutableStateOf(listOf<String>()) }
    var running by remember { mutableStateOf(true) }

    LaunchedEffect(running) {
        while (running && timeLeft > 0) {
            delay(1000)
            timeLeft--
        }
        if (timeLeft <= 0) {
            running = false
            onFinish(score)
        }
    }

    fun nextQuestion() {
        currentWord = words.random()
        val correct = currentWord!!.english
        val wrong = words.shuffled().take(3).map { it.english }
        options = (wrong + correct).shuffled()
    }

    LaunchedEffect(Unit) {
        nextQuestion()
    }

    if (!running) {
        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            Text(text = "انتهى الوقت! نقاطك: $score")
            Button(onClick = { running = true; score = 0; timeLeft = 60; nextQuestion() }) {
                Text("إعادة اللعب")
            }
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = "الوقت المتبقي: $timeLeft ثانية")
        Text(text = "النقاط: $score")
        currentWord?.let { w ->
            Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = w.arabic)
                }
            }
            options.forEach { opt ->
                Button(onClick = {
                    if (opt == w.english) score += 10
                    nextQuestion()
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(opt)
                }
            }
        }
    }
}
