package com.example.englishfromzero.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [WordItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
}
